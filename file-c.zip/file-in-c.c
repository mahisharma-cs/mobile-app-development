# include <stdio.h> 
# include <string.h> 

int main( ) 
{ 
	FILE *filePointer ; 
	
	char dataToBeWritten[50]; 
	int i;
		
	filePointer = fopen("GfgTest.txt", "w") ; 
	if ( filePointer == NULL ) 
	{ 
		printf( "GfgTest.c file failed to open." ) ; 
	} 
	else
	{ 
		printf("The file is now opened.\n") ; 
		printf("\nEnter the data you want to insert into your file : \n");
		
		
		// for(i=0;i<50;i++){
			// scanf("%c",&dataToBeWritten[i]);
			// if(dataToBeWritten[i]==(char)13)
				// break;
			gets(dataToBeWritten);
		// }
		
		
		if ( strlen ( dataToBeWritten ) > 0 ) 
		{ 
			fputs(dataToBeWritten, filePointer) ; 
			fputs("\n", filePointer) ; 
		} 
		fclose(filePointer) ; 
		
		printf("\nData successfully written in file GfgTest.txt\n"); 
		printf("The file is now closed.") ; 
	} 
	return 0;		 
} 